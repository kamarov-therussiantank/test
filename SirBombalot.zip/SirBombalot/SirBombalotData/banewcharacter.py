from bastd.actor.spazappearance import *

# YouTuber byANG3L #####################################
t         = Appearance('Sir Bombalot')
t.color_texture      = 'knightColor'
t.color_mask_texture = 'knightColorMask'
t.default_color      = (0.4, 0.5, 0.4)
t.default_highlight  = (1, 0.5, 0.3)
t.icon_texture       = 'knightIcon'
t.icon_mask_texture  = 'knightIconColorMask'
t.head_model         = 'knightHead'
t.torso_model        = 'knightTorso'
t.pelvis_model       = 'knightPelvis'
t.upper_arm_model    = 'knightUpperArm'
t.forearm_model      = 'knightForeArm'
t.hand_model         = 'knightHand'
t.upper_leg_model    = 'knightUpperLeg'
t.lower_leg_model    = 'knightLowerLeg'
t.toes_model         = 'knightToes'
sounds               = ['knight1', 'knight2', 'knight3', 'knight4', 'knight5', 'knight6']
soundsHit            = ['knight1', 'knight2', 'knight3', 'knight4', 'knight5', 'knight6']
t.attack_sounds      = sounds
t.jump_sounds        = sounds
t.impact_sounds      = soundsHit
t.death_sounds       = ['knightDeath1', 'knightDeath2']
t.pickup_sounds      = sounds
t.fall_sounds        = ["knightFall"]
t.style              = 'cyborg'
